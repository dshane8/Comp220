//
// Created by Dylan Shane on 12/18/17.
//

#ifndef BOOKSTORE_TESTER_H
#define BOOKSTORE_TESTER_H


class Tester {
public:
    void PersonTest();

    void BookTest();

    void bookStoreTester();

};


#endif //BOOKSTORE_TESTER_H
