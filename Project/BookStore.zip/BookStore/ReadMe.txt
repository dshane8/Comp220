***** READ ME *********

The Following Is Important Information About The Use of This Program

*********************************************************************


USER INPUT:
the user input is simple, the program handles most mistakes, the only thing to to look for
is that if the correct key for a command is entered no matter what is after it, the
command will execute (e.g. user input = asddfsdv   the "A" command to add a book will
trigger).