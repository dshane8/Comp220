//
// Created by Dylan Shane on 12/18/17.
//

#ifndef BOOKSTORE_INTERFACE_H
#define BOOKSTORE_INTERFACE_H

class Interface{
public:

    void run();
};

#endif //BOOKSTORE_INTERFACE_H
